# Question Paper Submission System (QPSS)

A web application for students and faculty to submit, manage, and approve question papers for examinations.

## Features

- **User Authentication**: Secure registration and login with role-based access (Student, Faculty, Admin)
- **Question Paper Management**: Upload, edit, and delete question papers
- **Approval Workflow**: Faculty and admin can review and approve/reject submissions
- **Dashboard**: Overview statistics and recent submissions
- **Search & Filter**: Find papers by title, subject, course, or status

## Tech Stack

- **Backend**: Flask (Python)
- **Database**: SQLite with SQLAlchemy
- **Frontend**: HTML, CSS, JavaScript
- **Authentication**: Werkzeug password hashing

## Project Structure

```
paper_checking/
├── app.py                 # Main Flask application
├── config.py              # Configuration settings
├── models.py              # Database models
├── requirements.txt       # Python dependencies
├── uploads/               # Uploaded question papers
├── static/
│   ├── css/
│   │   └── style.css     # Main stylesheet
│   └── js/
│       └── script.js     # JavaScript functionality
└── templates/
    ├── base.html         # Base template
    ├── auth/             # Authentication templates
    │   ├── login.html
    │   └── register.html
    ├── main/             # Main application templates
    │   ├── dashboard.html
    │   ├── papers.html
    │   ├── upload.html
    │   ├── view_paper.html
    │   ├── edit_paper.html
    │   ├── approvals.html
    │   └── approve_paper.html
    └── errors/           # Error pages
        ├── 404.html
        └── 500.html
```

## Installation

1. **Create a virtual environment** (optional but recommended):
   
```
bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   
```

2. **Install dependencies**:
   
```
bash
   pip install -r requirements.txt
   
```

3. **Run the application**:
   
```
bash
   python app.py
   
```

4. **Access the application**:
   Open your browser and navigate to `http://localhost:5000`

## Default Admin Account

The application creates a default admin user on first run:
- **Email**: admin@example.com
- **Password**: admin123

## User Roles

- **Student**: Can upload question papers and view their own submissions
- **Faculty**: All student permissions + can review and approve/reject papers
- **Admin**: Full access to all features + user management

## File Upload

- **Allowed formats**: PDF, DOC, DOCX
- **Maximum size**: 16MB
- Files are stored in the `uploads/` directory

## Development

The application runs in debug mode by default. For production deployment, ensure to:
1. Change the `SECRET_KEY` in `config.py`
2. Use a production-grade database
3. Set `debug=False` in the app.run() call

## License

This project is for educational purposes.
