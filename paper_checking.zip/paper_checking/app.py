from flask import Flask, render_template, redirect, url_for, request, flash, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from functools import wraps
import os
from datetime import datetime

from config import Config
from models import db, User, QuestionPaper, Approval

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
db.init_app(app)

# Create upload folder if not exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


# ========== Helper Functions ==========

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def get_user_by_id(user_id):
    """Get user by ID."""
    return User.query.get(user_id)


# ========== Login Required Decorator ==========

def login_required(f):
    """Decorator to require login for routes."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def role_required(roles):
    """Decorator to require specific roles for routes."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('login'))
            
            user = get_user_by_id(session['user_id'])
            if user.role not in roles:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ========== Authentication Routes ==========

@app.route('/')
def index():
    """Home page - redirect to login or dashboard."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page."""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        
        if not email or not password:
            flash('Please provide both email and password.', 'danger')
            return render_template('auth/login.html')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_role'] = user.role
            session.permanent = True
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
    
    return render_template('auth/login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page."""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        role = request.form.get('role', 'student')
        
        # Validation
        if not name or not email or not password:
            flash('Please fill in all required fields.', 'danger')
            return render_template('auth/register.html')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('auth/register.html')
        
        if len(password) < 8:
            flash('Password must be at least 8 characters long.', 'danger')
            return render_template('auth/register.html')
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            flash('An account with this email already exists.', 'danger')
            return render_template('auth/register.html')
        
        # Create new user
        user = User(name=name, email=email, role=role)
        user.set_password(password)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.', 'danger')
            return render_template('auth/register.html')
    
    return render_template('auth/register.html')


@app.route('/logout')
def logout():
    """User logout."""
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('login'))


# ========== Dashboard Routes ==========

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard with overview statistics."""
    user = get_user_by_id(session['user_id'])
    
    # Get statistics based on role
    if user.is_admin():
        # Admin sees all papers
        total_papers = QuestionPaper.query.count()
        pending_papers = QuestionPaper.query.filter(
            QuestionPaper.status.in_(['submitted', 'under_review'])
        ).count()
        approved_papers = QuestionPaper.query.filter_by(status='approved').count()
        rejected_papers = QuestionPaper.query.filter_by(status='rejected').count()
        recent_papers = QuestionPaper.query.order_by(QuestionPaper.created_at.desc()).limit(5).all()
    elif user.is_faculty():
        # Faculty sees all papers
        total_papers = QuestionPaper.query.count()
        pending_papers = QuestionPaper.query.filter(
            QuestionPaper.status.in_(['submitted', 'under_review'])
        ).count()
        approved_papers = QuestionPaper.query.filter_by(status='approved').count()
        rejected_papers = QuestionPaper.query.filter_by(status='rejected').count()
        recent_papers = QuestionPaper.query.order_by(QuestionPaper.created_at.desc()).limit(5).all()
    else:
        # Students see only their papers
        total_papers = QuestionPaper.query.filter_by(user_id=user.id).count()
        pending_papers = QuestionPaper.query.filter_by(
            user_id=user.id
        ).filter(
            QuestionPaper.status.in_(['submitted', 'under_review'])
        ).count()
        approved_papers = QuestionPaper.query.filter_by(
            user_id=user.id, status='approved'
        ).count()
        rejected_papers = QuestionPaper.query.filter_by(
            user_id=user.id, status='rejected'
        ).count()
        recent_papers = QuestionPaper.query.filter_by(
            user_id=user.id
        ).order_by(QuestionPaper.created_at.desc()).limit(5).all()
    
    stats = {
        'total': total_papers,
        'pending': pending_papers,
        'approved': approved_papers,
        'rejected': rejected_papers
    }
    
    return render_template('main/dashboard.html', 
                           user=user, 
                           stats=stats, 
                           recent_papers=recent_papers)


# ========== Question Paper Routes ==========

@app.route('/papers')
@login_required
def papers():
    """List all question papers with filters."""
    user = get_user_by_id(session['user_id'])
    
    # Get filter parameters
    status = request.args.get('status', '')
    search = request.args.get('search', '')
    
    # Build query based on role
    if user.is_admin() or user.is_faculty():
        query = QuestionPaper.query
    else:
        query = QuestionPaper.query.filter_by(user_id=user.id)
    
    # Apply filters
    if status:
        query = query.filter_by(status=status)
    if search:
        query = query.filter(
            (QuestionPaper.title.contains(search)) | 
            (QuestionPaper.subject.contains(search)) |
            (QuestionPaper.course.contains(search))
        )
    
    # Order by most recent
    papers = query.order_by(QuestionPaper.created_at.desc()).all()
    
    return render_template('main/papers.html', papers=papers, user=user)


@app.route('/papers/upload', methods=['GET', 'POST'])
@login_required
def upload_paper():
    """Upload a new question paper."""
    user = get_user_by_id(session['user_id'])
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        subject = request.form.get('subject', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', '').strip()
        description = request.form.get('description', '').strip()
        status_submit = request.form.get('submit_type', 'draft')
        
        # Validation
        if not title or not subject or not course or not semester:
            flash('Please fill in all required fields.', 'danger')
            return render_template('main/upload.html', user=user)
        
        # Handle file upload
        file = request.files.get('file')
        file_path = None
        file_name = None
        
        if file and file.filename:
            if not allowed_file(file.filename):
                flash('Invalid file type. Allowed types: PDF, DOC, DOCX', 'danger')
                return render_template('main/upload.html', user=user)
            
            # Save file
            file_name = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            file_path = f"{timestamp}_{file_name}"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], file_path))
        
        # Create question paper
        paper = QuestionPaper(
            title=title,
            subject=subject,
            course=course,
            semester=semester,
            description=description,
            file_path=file_path,
            file_name=file_name,
            status='submitted' if status_submit == 'submit' else 'draft',
            user_id=user.id
        )
        
        try:
            db.session.add(paper)
            db.session.commit()
            flash('Question paper uploaded successfully!', 'success')
            return redirect(url_for('papers'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while uploading. Please try again.', 'danger')
            return render_template('main/upload.html', user=user)
    
    return render_template('main/upload.html', user=user)


@app.route('/papers/<int:paper_id>')
@login_required
def view_paper(paper_id):
    """View a question paper details."""
    user = get_user_by_id(session['user_id'])
    paper = QuestionPaper.query.get_or_404(paper_id)
    
    # Check permissions
    if not user.is_admin() and not user.is_faculty() and paper.user_id != user.id:
        flash('You do not have permission to view this paper.', 'danger')
        return redirect(url_for('papers'))
    
    # Get approval history
    approvals = Approval.query.filter_by(paper_id=paper_id).order_by(Approval.created_at.desc()).all()
    
    return render_template('main/view_paper.html', paper=paper, approvals=approvals, user=user)


@app.route('/papers/<int:paper_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_paper(paper_id):
    """Edit a question paper."""
    user = get_user_by_id(session['user_id'])
    paper = QuestionPaper.query.get_or_404(paper_id)
    
    # Check permissions - only owner can edit (unless admin/faculty)
    if not user.is_admin() and not user.is_faculty() and paper.user_id != user.id:
        flash('You do not have permission to edit this paper.', 'danger')
        return redirect(url_for('papers'))
    
    # Can only edit if not approved
    if paper.status == 'approved':
        flash('Approved papers cannot be edited.', 'warning')
        return redirect(url_for('view_paper', paper_id=paper_id))
    
    if request.method == 'POST':
        paper.title = request.form.get('title', '').strip()
        paper.subject = request.form.get('subject', '').strip()
        paper.course = request.form.get('course', '').strip()
        paper.semester = request.form.get('semester', '').strip()
        paper.description = request.form.get('description', '').strip()
        
        # Handle file upload if new file provided
        file = request.files.get('file')
        if file and file.filename:
            if not allowed_file(file.filename):
                flash('Invalid file type. Allowed types: PDF, DOC, DOCX', 'danger')
                return render_template('main/edit_paper.html', paper=paper, user=user)
            
            # Remove old file if exists
            if paper.file_path:
                old_path = os.path.join(app.config['UPLOAD_FOLDER'], paper.file_path)
                if os.path.exists(old_path):
                    os.remove(old_path)
            
            # Save new file
            file_name = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            paper.file_path = f"{timestamp}_{file_name}"
            paper.file_name = file_name
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], paper.file_path))
        
        try:
            db.session.commit()
            flash('Question paper updated successfully!', 'success')
            return redirect(url_for('view_paper', paper_id=paper_id))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while updating. Please try again.', 'danger')
    
    return render_template('main/edit_paper.html', paper=paper, user=user)


@app.route('/papers/<int:paper_id>/delete', methods=['POST'])
@login_required
def delete_paper(paper_id):
    """Delete a question paper."""
    user = get_user_by_id(session['user_id'])
    paper = QuestionPaper.query.get_or_404(paper_id)
    
    # Check permissions
    if not user.is_admin() and not user.is_faculty() and paper.user_id != user.id:
        flash('You do not have permission to delete this paper.', 'danger')
        return redirect(url_for('papers'))
    
    # Can only delete if not approved
    if paper.status == 'approved':
        flash('Approved papers cannot be deleted.', 'warning')
        return redirect(url_for('view_paper', paper_id=paper_id))
    
    try:
        # Remove file if exists
        if paper.file_path:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], paper.file_path)
            if os.path.exists(file_path):
                os.remove(file_path)
        
        db.session.delete(paper)
        db.session.commit()
        flash('Question paper deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while deleting. Please try again.', 'danger')
    
    return redirect(url_for('papers'))


# ========== Approval Routes ==========

@app.route('/approvals')
@login_required
@role_required(['faculty', 'admin'])
def approvals():
    """View approval queue."""
    user = get_user_by_id(session['user_id'])
    
    # Get papers that need review
    papers = QuestionPaper.query.filter(
        QuestionPaper.status.in_(['submitted', 'under_review'])
    ).order_by(QuestionPaper.created_at.asc()).all()
    
    return render_template('main/approvals.html', papers=papers, user=user)


@app.route('/papers/<int:paper_id>/approve', methods=['GET', 'POST'])
@login_required
@role_required(['faculty', 'admin'])
def approve_paper(paper_id):
    """Approve a question paper."""
    user = get_user_by_id(session['user_id'])
    paper = QuestionPaper.query.get_or_404(paper_id)
    
    if request.method == 'POST':
        action = request.form.get('action', '')
        comments = request.form.get('comments', '').strip()
        
        if action not in ['approve', 'reject']:
            flash('Invalid action.', 'danger')
            return redirect(url_for('approvals'))
        
        # Update paper status
        paper.status = 'approved' if action == 'approve' else 'rejected'
        
        # Create approval record
        approval = Approval(
            paper_id=paper_id,
            reviewer_id=user.id,
            status='approved' if action == 'approve' else 'rejected',
            comments=comments
        )
        
        try:
            db.session.add(approval)
            db.session.commit()
            flash(f'Question paper {action}d successfully!', 'success')
            return redirect(url_for('approvals'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('main/approve_paper.html', paper=paper, user=user)


# ========== File Download Route ==========

@app.route('/uploads/<filename>')
@login_required
def download_file(filename):
    """Download uploaded file."""
    user = get_user_by_id(session['user_id'])
    
    # Find paper by filename
    paper = QuestionPaper.query.filter_by(file_path=filename).first()
    
    if not paper:
        flash('File not found.', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check permissions
    if not user.is_admin() and not user.is_faculty() and paper.user_id != user.id:
        flash('You do not have permission to download this file.', 'danger')
        return redirect(url_for('dashboard'))
    
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)


# ========== Error Handlers ==========

@app.errorhandler(404)
def not_found_error(error):
    """Handle 404 errors."""
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    db.session.rollback()
    return render_template('errors/500.html'), 500


# ========== Initialize Database ==========

def init_db():
    """Initialize the database."""
    with app.app_context():
        db.create_all()
        
        # Create admin user if not exists
        admin = User.query.filter_by(email='admin@example.com').first()
        if not admin:
            admin = User(
                name='Administrator',
                email='admin@example.com',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print('Admin user created: admin@example.com / admin123')


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
