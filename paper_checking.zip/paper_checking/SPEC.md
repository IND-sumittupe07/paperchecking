# Question Paper Submission System - Specification

## 1. Project Overview

**Project Name:** Question Paper Submission System (QPSS)
**Project Type:** Web Application
**Core Functionality:** A secure, efficient platform for students and faculty to submit, manage, and approve question papers for examinations.
**Target Users:** Students, Faculty Members, Examination Cell Administrators

---

## 2. UI/UX Specification

### Layout Structure

**Pages:**
1. Login/Register Page
2. Dashboard (different views for Students, Faculty, Admin)
3. Upload Question Paper Page
4. View/Edit Question Paper Page
5. Approval Queue Page (for Faculty/Admin)
6. History/Archive Page

**Layout Components:**
- Fixed Navigation Bar (60px height)
- Sidebar Menu (240px width, collapsible on mobile)
- Main Content Area (fluid width)
- Footer (40px height)

**Responsive Breakpoints:**
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

### Visual Design

**Color Palette:**
- Primary: `#1a365d` (Deep Navy Blue)
- Secondary: `#2c5282` (Medium Blue)
- Accent: `#ed8936` (Warm Orange)
- Success: `#38a169` (Green)
- Warning: `#d69e2e` (Yellow)
- Error: `#e53e3e` (Red)
- Background: `#f7fafc` (Light Gray)
- Card Background: `#ffffff` (White)
- Text Primary: `#1a202c` (Dark Gray)
- Text Secondary: `#718096` (Medium Gray)

**Typography:**
- Headings: 'Playfair Display', serif
- Body: 'Source Sans Pro', sans-serif
- Font Sizes:
  - H1: 2.5rem (40px)
  - H2: 2rem (32px)
  - H3: 1.5rem (24px)
  - Body: 1rem (16px)
  - Small: 0.875rem (14px)

**Spacing System:**
- Base unit: 8px
- Margins: 8px, 16px, 24px, 32px, 48px
- Paddings: 8px, 16px, 24px, 32px
- Border Radius: 8px (cards), 4px (buttons/inputs)

**Visual Effects:**
- Card shadows: `0 4px 6px rgba(0, 0, 0, 0.1)`
- Hover shadows: `0 10px 15px rgba(0, 0, 0, 0.15)`
- Transitions: 0.3s ease-in-out
- Gradient header: linear-gradient(135deg, #1a365d 0%, #2c5282 100%)

### Components

**Navigation Bar:**
- Logo on left
- Navigation links center
- User profile dropdown on right
- Background: Primary color with white text

**Cards:**
- White background
- 8px border radius
- Subtle shadow
- Hover: lift effect with enhanced shadow

**Buttons:**
- Primary: Accent color background, white text
- Secondary: Outlined with primary color
- States: hover (darken 10%), active (darken 15%), disabled (50% opacity)

**Forms:**
- Input fields with 48px height
- Labels above inputs
- Validation messages below inputs
- Focus state: accent color border

**Tables:**
- Striped rows
- Hover highlight
- Sortable headers
- Pagination controls

**Status Badges:**
- Pending: Yellow background
- Approved: Green background
- Rejected: Red background
- Draft: Gray background

---

## 3. Functionality Specification

### Core Features

**1. User Authentication**
- User registration with email, password, role selection
- Login with email/password
- Logout functionality
- Session management
- Password requirements: min 8 chars, at least 1 letter and 1 number

**2. User Roles**
- Student: Can upload question papers, view own submissions
- Faculty: All student permissions + approve/reject papers
- Admin: All permissions + manage users, full system access

**3. Question Paper Management**
- Upload question paper (PDF, DOC, DOCX)
- Edit own question papers (if not approved)
- Delete own question papers (if not approved)
- View all question papers (based on permissions)

**4. Approval Workflow**
- Submit for approval
- Faculty/Admin can approve or reject
- Provide feedback/comments on rejection
- Track status: Draft → Submitted → Under Review → Approved/Rejected

**5. Dashboard**
- Statistics overview (total papers, pending, approved, rejected)
- Recent submissions list
- Quick actions

**6. Search and Filter**
- Search by title, subject, date
- Filter by status, course, semester

### User Interactions and Flows

**Registration Flow:**
1. User clicks "Register"
2. Fills form: name, email, password, confirm password, role
3. System validates inputs
4. Account created, redirect to login

**Login Flow:**
1. User enters email and password
2. System validates credentials
3. Redirect to dashboard based on role

**Upload Flow:**
1. User navigates to Upload page
2. Fills details: title, subject, course, semester, description
3. Uploads file
4. Submits for review or saves as draft

**Approval Flow:**
1. Faculty/Admin views approval queue
2. Reviews question paper
3. Can approve (changes status to Approved) or reject (with comments)
4. User receives notification of decision

### Data Handling

**Database Tables:**
- users (id, name, email, password_hash, role, created_at)
- question_papers (id, title, subject, course, semester, description, file_path, status, user_id, created_at, updated_at)
- approvals (id, paper_id, reviewer_id, status, comments, created_at)

### Edge Cases
- File upload size limit: 10MB
- Allowed file types: PDF, DOC, DOCX
- Session timeout: 30 minutes
- Concurrent edit handling
- File upload failure recovery

---

## 4. Acceptance Criteria

### Visual Checkpoints
- [ ] Login page displays with proper branding
- [ ] Dashboard shows statistics cards
- [ ] Navigation is responsive on all devices
- [ ] Forms have proper validation feedback
- [ ] Status badges display correct colors
- [ ] Tables are properly styled and responsive

### Functional Checkpoints
- [ ] Users can register with different roles
- [ ] Users can log in and log out
- [ ] Students can upload question papers
- [ ] Students can view their submissions
- [ ] Faculty can approve/reject papers
- [ ] Search and filter work correctly
- [ ] File uploads work with size/type validation
- [ ] Status updates reflect in real-time

### Security Checkpoints
- [ ] Passwords are hashed
- [ ] Unauthorized users cannot access protected pages
- [ ] Users can only edit their own papers (unless admin/faculty)
- [ ] Session management works correctly
