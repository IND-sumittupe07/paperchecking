import os

class Config:
    """Application configuration settings."""
    
    # Secret key for session management
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # Database configuration
    SQLALCHEMY_DATABASE_URI = 'sqlite:///paper_checking.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # File upload settings
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
    
    # Session settings
    PERMANENT_SESSION_LIFETIME = 30 * 60  # 30 minutes in seconds
    
    # Application settings
    ITEMS_PER_PAGE = 10
